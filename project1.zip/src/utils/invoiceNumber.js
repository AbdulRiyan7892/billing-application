
import { db } from "../database/db";

export function getFinancialYear(date = new Date()) {
  const year = date.getFullYear();
  const month = date.getMonth();

  const startYear = month >= 3 ? year : year - 1;

  return `${startYear}-${String(startYear + 1).slice(-2)}`;
}

export async function getNextInvoiceNumber(date = new Date()) {
  const financialYear = getFinancialYear(date);

  return await db.transaction(
    "rw",
    db.counters,
    async () => {
      const counter = await db.counters.get(financialYear);

      const nextNumber = counter
        ? counter.lastNumber + 1
        : 1;

      await db.counters.put({
        financialYear,
        lastNumber: nextNumber
      });

      return `${financialYear}/${String(nextNumber).padStart(3, "0")}`;
    }
  );
}
